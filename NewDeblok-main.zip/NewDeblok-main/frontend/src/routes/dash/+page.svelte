<h1>Welcome to SvelteKit</h1>
<div class="text-red-800">asdas</div>
<p>Visit <a href="https://kit.svelte.dev">kit.svelte.dev</a> to read the documentation</p>
