export const prerender = true;
export const ssr = false;
export const csr = true;
