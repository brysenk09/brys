<script>
	document.location = '/dash';
</script>
