export const prerender = false;
export const ssr = false;
export const csr = true;
